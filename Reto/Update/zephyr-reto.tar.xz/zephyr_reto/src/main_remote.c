/*
 * Simplified OpenAMP resource table example for STM32MP257F-DK
 *
 * - Single RPMsg endpoint ("rpmsg-client-sample")
 * - Periodically sends a counter message from M33 -> A35 every second
 * - Echoes back any message received from A35 -> M33
 *
 * Copyright (c) 2020, STMICROELECTRONICS
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#include <zephyr/kernel.h>
#include <zephyr/device.h>

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include <zephyr/drivers/ipm.h>

#include <openamp/open_amp.h>
#include <metal/sys.h>
#include <metal/io.h>
#include <resource_table.h>
#include <addr_translation.h>

#include <zephyr/drivers/clock_control/stm32_clock_control.h>
#include <zephyr/drivers/reset.h>

#include <zephyr/drivers/uart.h>
#include <zephyr/drivers/i2c.h>
#include <zephyr/drivers/sensor.h>

#include <zephyr/logging/log.h>
LOG_MODULE_REGISTER(openamp_simple);

#define SHM_DEVICE_NAME	"shm"

#if !DT_HAS_CHOSEN(zephyr_ipc_shm)
#error "Sample requires definition of shared memory for rpmsg"
#endif

#if CONFIG_IPM_MAX_DATA_SIZE > 0
#define	IPM_SEND(dev, w, id, d, s) ipm_send(dev, w, id, d, s)
#else
#define IPM_SEND(dev, w, id, d, s) ipm_send(dev, w, id, NULL, 0)
#endif

/* Constants derived from device tree */
#define SHM_NODE		DT_CHOSEN(zephyr_ipc_shm)
#define SHM_START_ADDR	DT_REG_ADDR(SHM_NODE)
#define SHM_SIZE		DT_REG_SIZE(SHM_NODE)

#define APP_TASK_STACK_SIZE (1024)
#define APP_WORKER_STACK_SIZE (1536)
#define SEND_PERIOD_MS 1000

K_THREAD_STACK_DEFINE(thread_mng_stack, APP_TASK_STACK_SIZE);
K_THREAD_STACK_DEFINE(thread_worker_stack, APP_WORKER_STACK_SIZE);

static struct k_thread thread_mng_data;
static struct k_thread thread_worker_data;

static const struct device *const ipm_handle =
	DEVICE_DT_GET(DT_CHOSEN(zephyr_ipc));

static metal_phys_addr_t shm_physmap = SHM_START_ADDR;
static metal_phys_addr_t rsc_tab_physmap;

static struct metal_io_region shm_io_data; /* shared memory */
static struct metal_io_region rsc_io_data; /* rsc_table memory */

static struct metal_io_region *shm_io = &shm_io_data;
static struct metal_io_region *rsc_io = &rsc_io_data;
static struct rpmsg_virtio_device rvdev;

static void *rsc_table;
static struct rpmsg_device *rpdev;

static struct rpmsg_endpoint ept;
static char rx_buf[64];
static size_t rx_len;

static K_SEM_DEFINE(data_sem, 0, 1);
static K_SEM_DEFINE(rx_sem, 0, 1);
static K_SEM_DEFINE(startup_sem, 0, 1);

static void platform_ipm_callback(const struct device *dev, void *context,
				  uint32_t id, volatile void *data)
{
	LOG_DBG("%s: msg received from mb %d", __func__, id);
	k_sem_give(&data_sem);
}

static int rpmsg_rx_callback(struct rpmsg_endpoint *ep, void *data,
			     size_t len, uint32_t src, void *priv)
{
	size_t copy_len = len < sizeof(rx_buf) ? len : sizeof(rx_buf);

	memcpy(rx_buf, data, copy_len);
	rx_len = copy_len;
	
	/* Explicitly bind the destination address to the sender if not already set */
	if (ep->dest_addr == RPMSG_ADDR_ANY) {
		ep->dest_addr = src;
	}

	k_sem_give(&rx_sem);

	return RPMSG_SUCCESS;
}

static void new_service_cb(struct rpmsg_device *rdev, const char *name,
			   uint32_t src)
{
	LOG_ERR("%s: unexpected ns service receive for name %s",
		__func__, name);
}

int mailbox_notify(void *priv, uint32_t id)
{
	ARG_UNUSED(priv);

	LOG_DBG("%s: msg received", __func__);
	IPM_SEND(ipm_handle, 0, id, &id, 4);

	return 0;
}

int platform_init(void)
{
	int rsc_size;
	struct metal_init_params metal_params = METAL_INIT_DEFAULTS;
	int status;

	status = metal_init(&metal_params);
	if (status) {
		LOG_ERR("metal_init: failed: %d", status);
		return -1;
	}

	/* declare shared memory region */
	metal_io_init(shm_io, (void *)SHM_START_ADDR, &shm_physmap,
		      SHM_SIZE, -1, 0, addr_translation_get_ops(shm_physmap));

	/* declare resource table region */
	rsc_table_get(&rsc_table, &rsc_size);
	rsc_tab_physmap = (uintptr_t)rsc_table;

	metal_io_init(rsc_io, rsc_table,
		      &rsc_tab_physmap, rsc_size, -1, 0, NULL);

	/* setup IPM */
	if (!device_is_ready(ipm_handle)) {
		LOG_ERR("IPM device is not ready");
		return -1;
	}

	ipm_register_callback(ipm_handle, platform_ipm_callback, NULL);

	status = ipm_set_enabled(ipm_handle, 1);
	if (status) {
		LOG_ERR("ipm_set_enabled failed");
		return -1;
	}

	return 0;
}

static void cleanup_system(void)
{
	ipm_set_enabled(ipm_handle, 0);
	rpmsg_deinit_vdev(&rvdev);
	metal_finish();
}

struct rpmsg_device *
platform_create_rpmsg_vdev(unsigned int vdev_index,
			   unsigned int role,
			   void (*rst_cb)(struct virtio_device *vdev),
			   rpmsg_ns_bind_cb ns_cb)
{
	struct fw_rsc_vdev_vring *vring_rsc;
	struct virtio_device *vdev;
	int ret;

	vdev = rproc_virtio_create_vdev(VIRTIO_DEV_DEVICE, VDEV_ID,
					rsc_table_to_vdev(rsc_table),
					rsc_io, NULL, mailbox_notify, NULL);

	if (!vdev) {
		LOG_ERR("failed to create vdev");
		return NULL;
	}

	/* wait master rpmsg init completion */
	rproc_virtio_wait_remote_ready(vdev);

	vring_rsc = rsc_table_get_vring0(rsc_table);
	ret = rproc_virtio_init_vring(vdev, 0, vring_rsc->notifyid,
				      (void *)vring_rsc->da, rsc_io,
				      vring_rsc->num, vring_rsc->align);
	if (ret) {
		LOG_ERR("failed to init vring 0");
		goto failed;
	}

	vring_rsc = rsc_table_get_vring1(rsc_table);
	ret = rproc_virtio_init_vring(vdev, 1, vring_rsc->notifyid,
				      (void *)vring_rsc->da, rsc_io,
				      vring_rsc->num, vring_rsc->align);
	if (ret) {
		LOG_ERR("failed to init vring 1");
		goto failed;
	}

	ret = rpmsg_init_vdev(&rvdev, vdev, ns_cb, shm_io, NULL);
	if (ret) {
		LOG_ERR("failed rpmsg_init_vdev");
		goto failed;
	}

	return rpmsg_virtio_get_rpmsg_device(&rvdev);

failed:
	rproc_virtio_remove_vdev(vdev);

	return NULL;
}

/* =====================================
 * GLOBAL SENSOR VARIABLES & BUFFERS 
 * ===================================== */
static const struct device *uart_dev;

static double gps_lat = 0.0;
static double gps_lon = 0.0;
static double gps_alt = 0.0;
static bool gps_has_fix = false;

static uint16_t tof_distance = 0;
static struct sensor_value bme_temp = {0};
static struct sensor_value bme_press = {0};

static char nmea_buffer[128];
static int nmea_pos = 0;
static bool nmea_ready = false;

/* =====================================
 * HELPER FUNCTIONS
 * ===================================== */
/* Constantly drain the UART FIFO so GPS characters are never dropped */
static void drain_gps_rx(void) {
    if (!uart_dev) return;
    uint8_t c;
    while (uart_poll_in(uart_dev, &c) == 0) {
        if (nmea_ready) continue;
        
        /* THE FIX: Always synchronize to the start of a new NMEA sentence! */
        if (c == '$') {
            nmea_pos = 0;
        }
        if (c == '\n' || nmea_pos >= (int)sizeof(nmea_buffer) - 1) {
            nmea_buffer[nmea_pos] = '\0';
            nmea_ready = true;
        } else if (c != '\r') {
            nmea_buffer[nmea_pos++] = c;
        }
    }
}

/* Print string, and drain GPS while waiting for UART TX */
static void uart_print(const char *str)
{
    if (!uart_dev) return;
    while (*str) {
        uart_poll_out(uart_dev, *str++);
        drain_gps_rx(); /* Prevents GPS data loss! */
    }
}

static const char *nmea_field(const char *sentence, int field)
{
    for (int i = 0; i < field; i++) {
        sentence = strchr(sentence, ',');
        if (!sentence) return "";
        sentence++;
    }
    return sentence;
}

static double nmea_to_degrees(const char *raw, int deg_digits)
{
    char buf[16];
    int i = 0;
    while (raw[i] && raw[i] != ',' && i < (int)sizeof(buf) - 1) {
        buf[i] = raw[i];
        i++;
    }
    buf[i] = '\0';
    double val = atof(buf);
    int degrees = (int)(val / 100);
    double minutes = val - (degrees * 100);
    return degrees + (minutes / 60.0);
}

/* Updates the global GPS variables silently */
static void parse_gga(const char *sentence)
{
    const char *lat_raw = nmea_field(sentence, 2);
    const char *lat_dir = nmea_field(sentence, 3);
    const char *lon_raw = nmea_field(sentence, 4);
    const char *lon_dir = nmea_field(sentence, 5);
    const char *fix_str = nmea_field(sentence, 6);
    const char *alt_raw = nmea_field(sentence, 9);
    
    int fix = atoi(fix_str);
    if (fix == 0 || lat_raw[0] == ',') {
        gps_has_fix = false;
        return;
    }
    
    gps_has_fix = true;
    gps_lat = nmea_to_degrees(lat_raw, 2);
    gps_lon = nmea_to_degrees(lon_raw, 3);
    if (lat_dir[0] == 'S') gps_lat = -gps_lat;
    if (lon_dir[0] == 'W') gps_lon = -gps_lon;
    gps_alt = atof(alt_raw);
}

/* =====================================
 * VL53L0X DRIVER
 * ===================================== */
#define VL53L0X_ADDR 0x29
static uint8_t stop_var;

static int vl_wr(const struct device *i2c, uint8_t reg, uint8_t val) {
    uint8_t buf[2] = {reg, val};
    return i2c_write(i2c, buf, 2, VL53L0X_ADDR);
}
static int vl_rd(const struct device *i2c, uint8_t reg, uint8_t *val) {
    return i2c_write_read(i2c, VL53L0X_ADDR, &reg, 1, val, 1);
}
static int vl_rd16(const struct device *i2c, uint8_t reg, uint16_t *val) {
    uint8_t buf[2];
    int ret = i2c_write_read(i2c, VL53L0X_ADDR, &reg, 1, buf, 2);
    *val = (buf[0] << 8) | buf[1];
    return ret;
}

static int vl53l0x_init(const struct device *i2c) {
    vl_wr(i2c, 0x88, 0x00); vl_wr(i2c, 0x80, 0x01); vl_wr(i2c, 0xFF, 0x01);
    vl_wr(i2c, 0x00, 0x00); vl_rd(i2c, 0x91, &stop_var); vl_wr(i2c, 0x00, 0x01);
    vl_wr(i2c, 0xFF, 0x00); vl_wr(i2c, 0x80, 0x00);
    static const uint8_t tuning[][2] = {
        {0xFF,0x01},{0x00,0x00},{0xFF,0x00},{0x09,0x00},{0x10,0x00},{0x11,0x00},{0x24,0x01},{0x25,0xFF},
        {0x75,0x00},{0xFF,0x01},{0x4E,0x2C},{0x48,0x00},{0x30,0x20},{0xFF,0x00},{0x30,0x09},{0x54,0x00},
        {0x31,0x04},{0x32,0x03},{0x40,0x83},{0x46,0x25},{0x60,0x00},{0x27,0x00},{0x50,0x06},{0x51,0x00},
        {0x52,0x96},{0x56,0x08},{0x57,0x30},{0x61,0x00},{0x62,0x00},{0x64,0x00},{0x65,0x00},{0x66,0xA0},
        {0xFF,0x01},{0x22,0x32},{0x47,0x14},{0x49,0xFF},{0x4A,0x00},{0xFF,0x00},{0x7A,0x0A},{0x7B,0x00},
        {0x78,0x21},{0xFF,0x01},{0x23,0x34},{0x42,0x00},{0x44,0xFF},{0x45,0x26},{0x46,0x05},{0x40,0x40},
        {0x0E,0x06},{0x20,0x1A},{0x43,0x40},{0xFF,0x00},{0x34,0x03},{0x35,0x44},{0xFF,0x01},{0x31,0x04},
        {0x4B,0x09},{0x4C,0x05},{0x4D,0x04},{0xFF,0x00},{0x44,0x00},{0x45,0x20},{0x47,0x08},{0x48,0x28},
        {0x67,0x00},{0x70,0x04},{0x71,0x01},{0x72,0xFE},{0x76,0x00},{0x77,0x00},{0xFF,0x01},{0x0D,0x01},
        {0xFF,0x00},{0x80,0x01},{0x01,0xF8},{0xFF,0x01},{0x8E,0x01},{0x00,0x01},{0xFF,0x00},{0x80,0x00},
    };
    for (int i = 0; i < (int)(sizeof(tuning)/sizeof(tuning[0])); i++) {
        vl_wr(i2c, tuning[i][0], tuning[i][1]);
    }
    vl_wr(i2c, 0x0A, 0x04); vl_wr(i2c, 0x0B, 0x01);
    return 0;
}

static int vl53l0x_range_mm(const struct device *i2c, uint16_t *mm) {
    vl_wr(i2c, 0x80, 0x01); vl_wr(i2c, 0xFF, 0x01); vl_wr(i2c, 0x00, 0x00);
    vl_wr(i2c, 0x91, stop_var); vl_wr(i2c, 0x00, 0x01); vl_wr(i2c, 0xFF, 0x00);
    vl_wr(i2c, 0x80, 0x00); vl_wr(i2c, 0x00, 0x01);
    
    uint8_t val;
    for (int t = 0; t < 200; t++) {
        vl_rd(i2c, 0x13, &val);
        if (val & 0x07) break;
        drain_gps_rx(); /* <-- Prevents GPS data loss while waiting for laser bounce! */
        k_sleep(K_MSEC(5));
    }
    vl_rd16(i2c, 0x1E, mm);
    vl_wr(i2c, 0x0B, 0x01);
    return (val & 0x07) ? 0 : -1;
}

/* =====================================
 * MAIN
 * ===================================== */
int main(void)
{
    int ret;

    /* === UART INIT === */
    uart_dev = DEVICE_DT_GET(DT_NODELABEL(usart6));
    if (device_is_ready(uart_dev)) {
        struct uart_config cfg;
        if (uart_config_get(uart_dev, &cfg) == 0) {
            cfg.baudrate = 9600;
            uart_configure(uart_dev, &cfg);
        }
    }

    /* === VL53L0X INIT === */
    const struct device *const i2c_dev = DEVICE_DT_GET(DT_NODELABEL(i2c8));
    bool tof_ok = false;
    if (device_is_ready(i2c_dev) && vl53l0x_init(i2c_dev) == 0) {
        tof_ok = true;
    }

    /* === BME280 INIT === */
    const struct device *const bme280 = DEVICE_DT_GET_ANY(bosch_bme280);
    bool bme_ok = false;
    if (device_is_ready(bme280)) {
        bme_ok = true;
    }

    /* === OPENAMP INIT === */
    ret = platform_init();
    if (ret) {
        uart_print("Failed to init OpenAMP platform\r\n");
    } else {
        rpdev = platform_create_rpmsg_vdev(0, VIRTIO_DEV_DEVICE, NULL, new_service_cb);
        if (rpdev) {
            /* Create the endpoint that the A35 Python script connects to */
            ret = rpmsg_create_ept(&ept, rpdev, "rpmsg-tty",
                                   RPMSG_ADDR_ANY, RPMSG_ADDR_ANY,
                                   rpmsg_rx_callback, NULL);
            if (ret == 0) {
                uart_print("OpenAMP Endpoint created!\r\n");
            }
        }
    }

    /* === MAIN LOOP === */
    while (1) {
        /* 1. Poll GPS constantly to prevent drops */
        drain_gps_rx();
        if (nmea_ready) {
            if (strncmp(nmea_buffer, "$GPGGA", 6) == 0 ||
                strncmp(nmea_buffer, "$GNGGA", 6) == 0) {
                parse_gga(nmea_buffer);
            }
            nmea_pos = 0;
            nmea_ready = false;
        }

        /* 2. Process incoming OpenAMP IPCC Mailbox interrupts without blocking */
        if (k_sem_take(&data_sem, K_NO_WAIT) == 0) {
            rproc_virtio_notified(rvdev.vdev, VRING1_ID);
        }

        /* 3. Output Aggregated Format every 1000ms */
        uint32_t now = k_uptime_get_32();
        static uint32_t last_print_time = 0;
        
        if (now - last_print_time >= 1000) {
            last_print_time = now;
            
            /* Fetch latest data */
            if (tof_ok) vl53l0x_range_mm(i2c_dev, &tof_distance);
            
            if (bme_ok && sensor_sample_fetch(bme280) == 0) {
                sensor_channel_get(bme280, SENSOR_CHAN_AMBIENT_TEMP, &bme_temp);
                sensor_channel_get(bme280, SENSOR_CHAN_PRESS, &bme_press);
            }
            
            /* Build a single large string for both UART and OpenAMP */
            char rpmsg_buf[512];
            int len = 0;
            
            if (gps_has_fix) {
                len += snprintf(rpmsg_buf + len, sizeof(rpmsg_buf) - len, 
                                "[NEO6MV2]:\tX=%03.4f, Y=%03.4f, Z=%03.1f\r", gps_lat, gps_lon, gps_alt);
            } else {
                len += snprintf(rpmsg_buf + len, sizeof(rpmsg_buf) - len, 
                                "[NEO6MV2]:\tNo fix yet...\r");
            }
            
            if (tof_ok) {
                len += snprintf(rpmsg_buf + len, sizeof(rpmsg_buf) - len, 
                                "[VL53L0X]:\tD=%04u\r", tof_distance);
            }
            
                        /* Robust BME280 Read and Print */
            if (bme_ok) {
                int fetch_err = sensor_sample_fetch(bme280);
                if (fetch_err == 0) {
                    sensor_channel_get(bme280, SENSOR_CHAN_AMBIENT_TEMP, &bme_temp);
                    sensor_channel_get(bme280, SENSOR_CHAN_PRESS, &bme_press);
                    
                    /* Use abs() to prevent printing double negative signs for val2 */
                    len += snprintf(rpmsg_buf + len, sizeof(rpmsg_buf) - len, 
                                    "[BME280]:\tT=%03d.%04d, P=%03d.%04d\r\n",
                                    bme_temp.val1, abs(bme_temp.val2)/100, 
                                    bme_press.val1, abs(bme_press.val2)/100);
                } else {
                    len += snprintf(rpmsg_buf + len, sizeof(rpmsg_buf) - len, 
                                    "[BME280]:\tI2C Fetch Error %d\r\n", fetch_err);
                }
            }

            
            /* A. Print it to the local M33 Serial Console */
            uart_print(rpmsg_buf);
            
            /* B. Send it over RPMsg to the Cortex-A35 (Linux) */
            /* We only send if ept.dest_addr is set, which happens automatically 
               in rpmsg_rx_callback when the Python script first says "hello" */
            if (ept.dest_addr != RPMSG_ADDR_ANY) {
                rpmsg_send(&ept, rpmsg_buf, len);
            }
        }
        
        k_yield();
    }
    return 0;
}
